import os

def get_config():
    return {
        "S3_BUCKET": os.getenv("S3_BUCKET", "your-bucket-name"),
        "SNS_TOPIC_ARN": os.getenv("SNS_TOPIC_ARN", "arn:aws:sns:us-east-1:123456789012:FileProcessingAlerts"),
        "DB_HOST": os.getenv("DB_HOST", "localhost"),
        "DB_USER": os.getenv("DB_USER", "user"),
        "DB_PASSWORD": os.getenv("DB_PASSWORD", "password"),
        "DB_NAME": os.getenv("DB_NAME", "file_db"),
    }