import json
from process import process_file

def lambda_handler(event, context):
    result = process_file(event, context)
    return {
        "statusCode": 200,
        "body": json.dumps(result)
    }