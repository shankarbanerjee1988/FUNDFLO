import logging
import boto3
from store import upload_to_s3
from validate import validate_data

def process_file(event, context):
    s3_client = boto3.client("s3")
    bucket = event["Records"][0]["s3"]["bucket"]["name"]
    key = event["Records"][0]["s3"]["object"]["key"]
    
    response = s3_client.get_object(Bucket=bucket, Key=key)
    raw_data = response["Body"].read().decode("utf-8")
    
    try:
        validate_data(raw_data)
        upload_to_s3(raw_data, bucket, "processed/" + key)
        return {"status": "Processed successfully"}
    except Exception as e:
        return {"error": str(e)}