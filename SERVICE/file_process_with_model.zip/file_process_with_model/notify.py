def send_sns_notification(message):
    sns_client = boto3.client("sns")
    sns_client.publish(
        TopicArn="arn:aws:sns:us-east-1:123456789012:FileProcessingAlerts",
        Message=message,
    )