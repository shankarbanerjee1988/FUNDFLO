import time

def retry_logic(attempts, func, *args, **kwargs):
    for attempt in range(attempts):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            print(f"Attempt {attempt + 1} failed: {e}")
            time.sleep(2 ** attempt)
    raise Exception("Max retry attempts reached")