project/
├── main.py             # Lambda entry point
├── validate.py         # Schema validation
├── notify.py           # Error notifications (SNS, Email)
├── store.py            # S3 storage operations
├── config.py           # Configuration settings
├── logging.py          # Logging setup (CloudWatch, S3 logs)
├── process.py          # Core processing logic
├── transformations/    # Data transformation modules
│   ├── __init__.py
│   ├── compute.py      # Quantity computations
│   ├── finance.py      # Financial calculations
│   ├── text.py         # Text transformations
│   ├── date.py         # Date/time transformations
│   ├── formulas.py     # Computed columns & formulas
│   ├── lookup.py       # Lookup table integration
│   ├── api_enrich.py   # API-based data enrichment
│   ├── utils.py        # Helper functions
├── retry.py            # Retry logic for failed files
├── error_handler.py    # Error handling & reporting
├── database/           # PostgreSQL storage
│   ├── __init__.py
│   ├── models.py       # ORM models
│   ├── queries.py      # SQL queries
│   ├── connection.py   # DB connection management
├── notifications/      # Notifications module
│   ├── __init__.py
│   ├── sns.py          # SNS alerts
│   ├── email.py        # SMTP email notifications
│   ├── logging.py      # Logging errors to S3/CloudWatch
├── handlers/           # AWS Lambda handlers
│   ├── process_handler.py  # Handles file processing
│   ├── retry_handler.py    # Handles retries
│   ├── enrich_handler.py   # Handles enrichment
├── tests/              # Unit tests
│   ├── __init__.py
│   ├── test_validate.py
│   ├── test_transformations.py
│   ├── test_store.py
│   ├── test_database.py
│   ├── test_notify.py
│   ├── test_retry.py
├── requirements.txt    # Dependencies
├── serverless.yml      # Serverless configuration
├── README.md           # Documentation




