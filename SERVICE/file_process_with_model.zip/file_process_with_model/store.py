import boto3

def upload_to_s3(data, bucket, key):
    s3_client = boto3.client("s3")
    s3_client.put_object(Body=data, Bucket=bucket, Key=key)
    print(f"Uploaded processed data to {bucket}/{key}")