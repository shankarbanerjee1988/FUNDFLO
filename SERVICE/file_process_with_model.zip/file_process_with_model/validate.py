def validate_data(data):
    if not isinstance(data, dict):
        raise ValueError("Invalid data format. Expected JSON object.")
    return True