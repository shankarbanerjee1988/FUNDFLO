# transformations package initialization
from . import compute
from . import finance
from . import main

# Export key functions for easier imports
from .compute import process_quantity_computation, process_unit_conversion
from .finance import calculate_discount, calculate_profit_margin, calculate_tax, convert_currency

__all__ = [
    'main',
    'compute',
    'finance',
    'process_quantity_computation',
    'process_unit_conversion',
    'calculate_discount',
    'calculate_profit_margin',
    'calculate_tax',
    'convert_currency'
]