def apply_discount(total_price, discount_percent):
    """Apply a percentage discount."""
    return round(total_price * (1 - discount_percent / 100), 2)

def profit_margin(revenue, cost):
    """Calculate profit margin percentage."""
    return round((revenue - cost) / revenue * 100 if revenue > 0 else 0, 2)

def remaining_stock(initial_stock, sold_units):
    """Calculate remaining stock."""
    return max(0, initial_stock - sold_units)

def tax_amount(total_price, tax_rate):
    """Calculate tax amount based on a given tax rate."""
    return round(total_price * (tax_rate / 100), 2)

def convert_currency(amount, conversion_rate):
    """Convert currency based on exchange rate."""
    return round(amount * conversion_rate, 2)