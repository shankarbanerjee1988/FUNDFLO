import pandas as pd
import numpy as np
import logging

# Configure logging
logger = logging.getLogger()

def compute_item_quantity(calc_type, pcs, size, bun, alt_unit, numerator, denominator):
    """
    Compute item quantity based on:
    1. 'only_size' -> Size dimensions (pcs * width * height)
    2. 'alt_numerator_denominator' -> Alternative unit conversion (M2 <-> BOX)
    3. 'only_numerator_denominator' -> Simple numerator/denominator conversion without unit checks
    
    Args:
        calc_type (str): "only_size", "alt_numerator_denominator", or "only_numerator_denominator"
        pcs (float): Number of pieces
        size (str): Size in format "WxH"
        bun (str): Base unit name (e.g., "M2", "BOX")
        alt_unit (str): Alternative unit name
        numerator (float): Conversion numerator
        denominator (float): Conversion denominator
        
    Returns:
        float: Computed quantity value
    """
    itemQuantity = max(float(pcs), 0)  # Ensure pcs is non-negative

    if calc_type == "only_size":
        try:
            w, h = map(float, size.lower().split("x"))
            w = max(w, 0)
            h = max(h, 0)
        except ValueError:
            return 0  # Default to 0 if size format is invalid

        return round((itemQuantity * w * h) / (1000 * 1000), 3)  # Convert to square meters

    elif calc_type == "alt_numerator_denominator":
        if bun == "M2" and alt_unit == "BOX":
            ratio = float(numerator) / float(denominator)
            return round(itemQuantity * ratio, 3)
        elif bun == "BOX" and alt_unit == "M2":
            ratio = float(denominator) / float(numerator)
            return round(itemQuantity * ratio, 3)
        else:
            return itemQuantity  # Default to item pcs if no conversion rule matches

    elif calc_type == "only_numerator_denominator":
        return round(itemQuantity * (float(denominator) / float(numerator)), 3)

    return itemQuantity  # Default return if type is unknown

def process_quantity_computation(df, config):
    """
    Process quantity computations based on configuration.
    
    Parameters:
    - df: pandas DataFrame
    - config: dictionary with computation configuration
    
    Returns:
    - Updated pandas DataFrame
    """
    try:
        target_column = config.get('target_column')
        operation = config.get('operation', 'sum')
        columns = config.get('source_columns', [])
        
        # Check if all required columns exist
        missing_columns = [col for col in columns if col not in df.columns]
        if missing_columns:
            logger.warning(f"Missing columns for computation: {missing_columns}")
            return df
        
        # Apply different operations
        if operation == 'sum':
            df[target_column] = df[columns].sum(axis=1)
        elif operation == 'product':
            # Start with 1 and multiply
            df[target_column] = 1
            for col in columns:
                df[target_column] *= df[col]
        elif operation == 'average':
            df[target_column] = df[columns].mean(axis=1)
        elif operation == 'weighted_average':
            weights = config.get('weights', [])
            if len(weights) != len(columns):
                logger.error("Number of weights must match number of columns")
                return df
            
            # Calculate weighted average
            weighted_sum = sum(df[col] * weight for col, weight in zip(columns, weights))
            weight_sum = sum(weights)
            df[target_column] = weighted_sum / weight_sum
        elif operation == 'custom':
            # Custom formula specified in the config
            formula = config.get('formula')
            if not formula:
                logger.error("Custom operation requires a formula")
                return df
            
            # Create a dictionary of variables for eval()
            variables = {}
            for col in columns:
                variables[col] = df[col]
            
            # Using numexpr would be safer here in production
            # For now, using eval with limited scope
            df[target_column] = eval(formula, {"__builtins__": {}}, variables)
        elif operation == 'item_quantity':
            # Get configuration for item quantity calculation
            calc_type = config.get('calc_type', 'only_size')
            pcs_col = config.get('pcs_column', 'pcs')
            size_col = config.get('size_column', 'size')
            base_unit_col = config.get('base_unit_column', 'base_unit')
            alt_unit_col = config.get('alt_unit_column', 'alt_unit')
            numerator_col = config.get('numerator_column', 'numerator')
            denominator_col = config.get('denominator_column', 'denominator')
            
            # Check if required columns exist
            required_cols = [pcs_col]
            if calc_type == 'only_size':
                required_cols.append(size_col)
            elif calc_type == 'alt_numerator_denominator':
                required_cols.extend([base_unit_col, alt_unit_col, numerator_col, denominator_col])
            elif calc_type == 'only_numerator_denominator':
                required_cols.extend([numerator_col, denominator_col])
            
            missing_cols = [col for col in required_cols if col not in df.columns]
            if missing_cols:
                logger.warning(f"Missing required columns for item quantity calculation: {missing_cols}")
                return df
            
            # Apply calculation row by row
            df[target_column] = df.apply(
                lambda row: compute_item_quantity(
                    calc_type,
                    row[pcs_col],
                    row.get(size_col, "0x0"),
                    row.get(base_unit_col, ""),
                    row.get(alt_unit_col, ""),
                    row.get(numerator_col, 1),
                    row.get(denominator_col, 1)
                ),
                axis=1
            )
        else:
            logger.warning(f"Unknown operation: {operation}")
        
        return df
    
    except Exception as e:
        logger.error(f"Error in quantity computation: {str(e)}")
        return df

def process_unit_conversion(df, config):
    """
    Process unit conversions based on configuration.
    
    Parameters:
    - df: pandas DataFrame
    - config: dictionary with conversion configuration
    
    Returns:
    - Updated pandas DataFrame
    """
    try:
        source_column = config.get('source_column')
        target_column = config.get('target_column', f"{source_column}_converted")
        source_unit = config.get('source_unit')
        target_unit = config.get('target_unit')
        conversion_factor = config.get('conversion_factor', 1.0)
        
        # Check if source column exists
        if source_column not in df.columns:
            logger.warning(f"Source column {source_column} not found in data")
            return df
        
        # Apply conversion
        df[target_column] = df[source_column] * conversion_factor
        
        # Log the conversion
        logger.info(f"Converted {source_column} from {source_unit} to {target_unit} as {target_column}")
        
        return df
    
    except Exception as e:
        logger.error(f"Error in unit conversion: {str(e)}")
        return df