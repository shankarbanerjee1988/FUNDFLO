import pandas as pd
import json
import logging
import os
from io import BytesIO
import yaml

# Import transformation modules
from . import compute
from . import finance

# Configure logging
logger = logging.getLogger()

# Path to transformation configurations
CONFIG_DIR = os.path.join(os.path.dirname(__file__), '..', 'config')

def load_transformation_config(file_type):
    """Load transformation configuration for a specific file type."""
    try:
        config_path = os.path.join(CONFIG_DIR, f"{file_type}_transforms.yaml")
        if not os.path.exists(config_path):
            logger.warning(f"Transformation config not found for {file_type}, using default")
            config_path = os.path.join(CONFIG_DIR, "default_transforms.yaml")
        
        with open(config_path, 'r') as file:
            return yaml.safe_load(file)
    except Exception as e:
        logger.error(f"Error loading transformation config: {str(e)}")
        # Return empty config as fallback
        return {}

def load_reference_data(reference_name):
    """Load reference data from file."""
    try:
        ref_path = os.path.join(CONFIG_DIR, 'reference', f"{reference_name}.json")
        if not os.path.exists(ref_path):
            logger.error(f"Reference data not found: {reference_name}")
            return {}
        
        with open(ref_path, 'r') as file:
            return json.load(file)
    except Exception as e:
        logger.error(f"Error loading reference data {reference_name}: {str(e)}")
        return {}

def read_file(file_path, file_type):
    """Read file based on its type."""
    try:
        if file_type in ['csv']:
            return pd.read_csv(file_path)
        elif file_type in ['xls', 'xlsx', 'xlsm']:
            return pd.read_excel(file_path)
        elif file_type == 'json':
            with open(file_path, 'r') as file:
                data = json.load(file)
            # Convert to DataFrame if it's a list of objects
            if isinstance(data, list):
                return pd.DataFrame(data)
            return data
        elif file_type == 'parquet':
            return pd.read_parquet(file_path)
        elif file_type == 'pdf':
            # PDF handling would depend on requirements
            # This is a placeholder for PDF extraction logic
            # Consider using libraries like PyPDF2, PDFMiner, etc.
            logger.warning("PDF transformation not fully implemented")
            return {"file_path": file_path, "content": "PDF content extraction placeholder"}
        else:
            raise ValueError(f"Unsupported file type: {file_type}")
    except Exception as e:
        logger.error(f"Error reading file {file_path}: {str(e)}")
        raise

def apply_column_rename(data, rename_mapping):
    """Rename columns based on mapping."""
    if not isinstance(data, pd.DataFrame):
        logger.warning("Column rename only works with DataFrame objects")
        return data
    
    try:
        # Filter mapping to only include columns that exist in the DataFrame
        valid_mapping = {old: new for old, new in rename_mapping.items() if old in data.columns}
        return data.rename(columns=valid_mapping)
    except Exception as e:
        logger.error(f"Error renaming columns: {str(e)}")
        return data

def apply_lookup_values(data, lookup_config):
    """Apply lookup transformations using reference tables."""
    if not isinstance(data, pd.DataFrame):
        logger.warning("Lookup transformation only works with DataFrame objects")
        return data
    
    try:
        for lookup in lookup_config:
            source_column = lookup.get('source_column')
            target_column = lookup.get('target_column', f"{source_column}_lookup")
            reference_table = lookup.get('reference_table')
            default_value = lookup.get('default_value', None)
            
            if source_column not in data.columns:
                logger.warning(f"Source column {source_column} not found in data")
                continue
                
            # Load reference data
            reference_data = load_reference_data(reference_table)
            if not reference_data:
                logger.warning(f"Reference data {reference_table} not found or empty")
                continue
            
            # Apply mapping
            data[target_column] = data[source_column].map(reference_data).fillna(default_value)
        
        return data
    except Exception as e:
        logger.error(f"Error applying lookup values: {str(e)}")
        return data

def apply_api_enrichment(data, enrichment_config):
    """Apply enrichment from external APIs."""
    # This is a placeholder for API enrichment logic
    # In a real implementation, this would call external APIs
    logger.info("API enrichment placeholder - would call external APIs here")
    return data

def apply_compute_transformations(data, compute_config):
    """Apply compute transformations."""
    if not isinstance(data, pd.DataFrame):
        logger.warning("Compute transformation only works with DataFrame objects")
        return data
    
    try:
        for computation in compute_config:
            computation_type = computation.get('type')
            
            if computation_type == 'quantity':
                data = compute.process_quantity_computation(data, computation)
            elif computation_type == 'unit_conversion':
                data = compute.process_unit_conversion(data, computation)
            else:
                logger.warning(f"Unknown computation type: {computation_type}")
        
        return data
    except Exception as e:
        logger.error(f"Error applying compute transformations: {str(e)}")
        return data

def apply_finance_transformations(data, finance_config):
    """Apply financial transformations."""
    if not isinstance(data, pd.DataFrame):
        logger.warning("Finance transformation only works with DataFrame objects")
        return data
    
    try:
        for calculation in finance_config:
            calculation_type = calculation.get('type')
            
            if calculation_type == 'discount':
                data = finance.calculate_discount(data, calculation)
            elif calculation_type == 'profit_margin':
                data = finance.calculate_profit_margin(data, calculation)
            elif calculation_type == 'tax':
                data = finance.calculate_tax(data, calculation)
            elif calculation_type == 'currency_conversion':
                data = finance.convert_currency(data, calculation)
            else:
                logger.warning(f"Unknown finance calculation type: {calculation_type}")
        
        return data
    except Exception as e:
        logger.error(f"Error applying finance transformations: {str(e)}")
        return data

def process(file_path, file_type):
    """Main processing function for transformations."""
    try:
        # Read the file
        data = read_file(file_path, file_type)
        
        # Load transformation configuration
        config = load_transformation_config(file_type)
        
        # Apply transformations according to config
        # 1. Rename columns
        if 'rename_columns' in config:
            data = apply_column_rename(data, config['rename_columns'])
        
        # 2. Apply lookups from reference tables
        if 'lookups' in config:
            data = apply_lookup_values(data, config['lookups'])
        
        # 3. Enrich data from external APIs
        if 'api_enrichment' in config:
            data = apply_api_enrichment(data, config['api_enrichment'])
        
        # 4. Apply compute transformations
        if 'compute' in config:
            data = apply_compute_transformations(data, config['compute'])
        
        # 5. Apply finance transformations
        if 'finance' in config:
            data = apply_finance_transformations(data, config['finance'])
        
        return data
    
    except Exception as e:
        logger.error(f"Error in transformation process: {str(e)}")
        raise